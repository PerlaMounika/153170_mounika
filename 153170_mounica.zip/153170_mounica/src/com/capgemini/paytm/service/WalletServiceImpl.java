package com.capgemini.paytm.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.paytm.beans.Customer;
import com.capgemini.paytm.beans.Wallet;
import com.capgemini.paytm.exception.InsufficientBalanceException;
import com.capgemini.paytm.exception.InvalidInputException;
import com.capgemini.paytm.repo.WalletRepo;
import com.capgemini.paytm.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {


public WalletRepo repo;
	
	public WalletServiceImpl(){
		repo= new WalletRepoImpl();
	}
	public WalletServiceImpl(Map<String, Customer> data){
		repo= new WalletRepoImpl(data);
	}
	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}
	public boolean validatephone(String phoneno) {
		
		String pattern1="[7-9]?[0-9]{10}";
		if(phoneno.matches(pattern1))
		{
			return true;
		}else {
			return false;
		}
	}
	public boolean validateName(String pName) {
		String pattern="[A-Z][a-zA-Z]*";
		if(pName.matches(pattern))
		{
			return true;
		}else {
			return false;
		}
	}
	WalletRepoImpl obj=new WalletRepoImpl();
	
	
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) throws Exception {
		System.out.println("in service layer");
		Customer cust=new Customer(name,mobileNo,new Wallet(amount));		
		acceptCustomerDetails(cust);
		System.out.println(cust);
		boolean result=repo.save(cust);
		System.out.println(result);
		//System.out.println(result);
		if(result==true)
			return cust;
		else
			return null;
			
		}

	public Customer showBalance(String mobileNo) throws SQLException {
		
		Customer customer=repo.findOne(mobileNo);		
		if(customer!=null)
			return customer;
		else
			throw new InvalidInputException("Invalid mobile no ");
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputException, SQLException {
		
		Customer sourceCustomer= repo.findOne(sourceMobileNo);
		Customer targetCustomer= repo.findOne(targetMobileNo);
		if((sourceCustomer!=null)&&(targetCustomer!=null))
		{
			Customer tcust=depositAmount(targetMobileNo, amount);
			Customer scust=withdrawAmount(sourceMobileNo, amount);
			repo.update(tcust);
			repo.update(scust);
			return scust;
		}
		else
			return null;
		

		
		
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException,SQLException {
		Customer cust=repo.findOne(mobileNo);
		try
		{
			if(cust!=null)
			{
				Wallet iAmount=cust.getWallet();
				BigDecimal updatedBalance=iAmount.getBalance().add(amount);
				Wallet wallet=new Wallet(updatedBalance);
				cust.setWallet(wallet);
				repo.update(cust);
				return cust;
			}
			else
			
				return null;
			
		}
		catch(Exception e)
		{
			System.err.println("invalid details");
			
		}
		return null;
	}
	
		

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws SQLException {
		try{
			Customer cust= repo.findOne(mobileNo);
			if(cust!=null)
			{
				Wallet iAmount=cust.getWallet();
				BigDecimal updatedBalance=iAmount.getBalance().subtract(amount);
				Wallet wallet=new Wallet(updatedBalance);
				cust.setWallet(wallet);
				repo.update(cust);
				return cust;
			}
			else
			
				return null;
			
		}
		catch(Exception e)
		{
			System.err.println("invalid details");
			
		}
		return null;
	}
	

public void acceptCustomerDetails(Customer cust)  {
	Scanner sc=new Scanner(System.in);
	while (true) {
		String str=cust.getMobileNo();
		if(validatephone(str))//method validate name
		{
			
			break;
		}
		else
		{
			System.err.println("Wrong Phone number!!\n Please Start with 9 ");
			System.out.println("Enter Phone number Again eg:9876543210");
			cust.setMobileNo(sc.next());
		}
	}
	while (true) {
		String str1=cust.getName();
		if(validateName(str1))//method validate name
		{
			break;
		}
		else
		{
			System.err.println("Wrong  Name!!\n Please Start with Capital letter ");
			System.out.println("Enter  Name Again eg:Name");
			cust.setName(sc.next());
		}
	}
}

}
